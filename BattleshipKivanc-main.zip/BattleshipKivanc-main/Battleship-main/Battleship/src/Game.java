import javax.swing.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


public class Game implements KeyListener {

    public static void main(String[] args) {
        Game game = new Game();
    }


    private GamePanel gamePanel;


    public Game() {
        String[] options = new String[] {"Easy", "Medium", "Hard"};
        String message = "Kolay hamleleri tamamen rastgele yapacaktır,\nMedium, gemi bulduğu bölgelere odaklanacak,"
                + "\nve Hard, Medium'a göre daha akıllı seçimler yapacak.";
        int difficultyChoice = JOptionPane.showOptionDialog(null, message,
                "Bir Yapay Zeka Zorluğu Seçin",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, options, options[0]);

        JFrame frame = new JFrame("Amiral Battı");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);

        gamePanel = new GamePanel(difficultyChoice);
        frame.getContentPane().add(gamePanel);

        frame.addKeyListener(this);
        frame.pack();
        frame.setVisible(true);
    }


    @Override
    public void keyPressed(KeyEvent e) {
        gamePanel.handleInput(e.getKeyCode());
    }


    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {}
}
